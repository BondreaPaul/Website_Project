<?php
function getTopBar($db) {
    session_start();
    $user_type = isset($_SESSION['type']) ? $_SESSION['type'] : 'guest';
    $username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
    $profile_link = 'LoginAsUser.php';

    // Set default home page based on user type
    $main_page_query = "SELECT redirect FROM usertypes WHERE nume = ?";
    $stmt = $db->prepare($main_page_query);
    $stmt->bind_param('s', $user_type);
    $stmt->execute();
    $result = $stmt->get_result();
    $main_page = 'GamesBroadcasts.php';
    if ($row = $result->fetch_assoc()) {
        $main_page = $row['redirect'];
    }
    $stmt->close();

    // Fetch pages for the current user from the database
    $user_id = isset($_SESSION["user_id"]) ? $_SESSION["user_id"] : 3;
    $page = basename($_SERVER['PHP_SELF']);

    $query = "SELECT pagini.menu, pagini.numemenu, pagini.pagina 
              FROM pagini 
              INNER JOIN drepturi ON drepturi.idpage = pagini.id 
              WHERE drepturi.iduser = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $sw = 0;
    $links = [];
    while ($row = $result->fetch_assoc()) {
        if ($row["pagina"] == $page) {
            $sw = 1;
        }
        if ($row["menu"] == 1) {
            $links[] = '<li><a href="' . htmlspecialchars($row['pagina']) . '">' . htmlspecialchars($row['numemenu']) . '</a></li>';
        }
    }
    $stmt->close();

    // If the user does not have rights to access this page, redirect to login
    if ($sw == 0) {
        header("Location: LoginAsUser.php");
        exit();
    }

    echo '<div class="top-bar">
      <div class="top-bar-left">
        <ul class="menu">
          <li class="menu-text">GamesBroadcasts</li>' . implode('', $links) . '
        </ul>
      </div>
    </div>';
}
?>















