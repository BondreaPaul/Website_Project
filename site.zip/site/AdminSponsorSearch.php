<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Sponsor Search</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

<form method="post" action="AdminSponsorSearch.php">
  <div class="d-flex justify-content-center">
    <div class="input-group" style="max-width: 400px;">
      <input type="text" id="text" name="text" class="form-control" placeholder="Text">
      <button type="submit" name="submit" class="btn btn-primary" data-mdb-ripple-init>Search<i class="fas fa-search"></i></button>
    </div>
  </div>
</form>

<?php
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=site', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}

$SW = 0;

if (isset($_POST['submit'])) {
    $key = $_POST['text'];
    $query = $pdo->prepare('SELECT * FROM sponsors WHERE companyname LIKE :keyword OR companysite LIKE :keyword');
    $query->bindValue(':keyword', '%'.$key.'%', PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_ASSOC);
    $rows = $query->rowCount();

    $SW = 1;
}

if ($SW == 1) {
    if ($rows > 0) {
        echo "<div class='container'>
        <div class='table-container'>
          <table class='table table-striped'>
            <thead>
              <tr>
                <th>#</th>
                <th>Company Name</th>
                <th>Amount</th>
                <th>Date Received</th>
                <th>Company Site</th>
                <th>Advert Length</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>";
        foreach ($results as $index => $myrow) {
            echo "<tr>";
            echo "<th scope='row'>" . htmlspecialchars($index + 1) . "</th>";
            echo "<td>" . htmlspecialchars($myrow["companyname"]) . "</td>";
            echo "<td>" . htmlspecialchars($myrow["amount"]) . "</td>";
            echo "<td>" . htmlspecialchars($myrow["datereceived"]) . "</td>";
            echo "<td><a href='" . htmlspecialchars($myrow["companysite"]) . "'>" . htmlspecialchars($myrow["companysite"]) . "</a></td>";
            echo "<td>" . htmlspecialchars($myrow["advertlength"]) . "</td>";
            echo "<td>
                    <a href='AdminSponsorEdit.php?id=" . htmlspecialchars($myrow['id']) . "' class='btn btn-primary'>Edit</a>
                    <a href='AdminSponsorDelete.php?id=" . htmlspecialchars($myrow['id']) . "' class='btn btn-danger'>Delete</a>
                  </td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
        echo "</div></div>";
    } else {
        echo "<br>No records found matching your search!";
    }
}
?>
<div class="text-center">
  <a href="AdminSponsorsList.php" class="btn btn-primary">Return</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
