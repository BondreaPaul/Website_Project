<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin's Sponsors</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh;
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

<!-- Crearea Entry -->
<form action="AdminSponsorCreate.php" method="POST">
  <div class="row justify-content-center mt-3">
    <div class="col-md-6">
      <div class="form-group">
        <label for="companyname">Company Name</label>
        <input type="text" class="form-control" id="companyname" name="companyname" required>
      </div>
      <div class="form-group">
        <label for="amount">Amount</label>
        <input type="number" class="form-control" id="amount" name="amount" required>
      </div>
      <div class="form-group">
        <label for="datereceived">Date Received</label>
        <input type="date" class="form-control" id="datereceived" name="datereceived" required>
      </div>
      <div class="form-group">
        <label for="companysite">Company Site</label>
        <input type="text" class="form-control" id="companysite" name="companysite" required>
      </div>
      <div class="form-group">
        <label for="advertlength">Advert Length</label>
        <input type="number" class="form-control" id="advertlength" name="advertlength" required>
      </div>
      <button type="submit" class="btn btn-success">Create</button>
    </div>
  </div>
</form>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $pdo = new PDO('mysql:host=127.0.0.1;dbname=site', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $companyname = $_POST['companyname'];
        $amount = $_POST['amount'];
        $datereceived = $_POST['datereceived'];
        $companysite = $_POST['companysite'];
        $advertlength = $_POST['advertlength'];

        $query = "INSERT INTO sponsors (companyname, amount, datereceived, companysite, advertlength) VALUES (:companyname, :amount, :datereceived, :companysite, :advertlength)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':companyname', $companyname);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':datereceived', $datereceived);
        $stmt->bindParam(':companysite', $companysite);
        $stmt->bindParam(':advertlength', $advertlength);

        if ($stmt->execute()) {
            header('Location: AdminSponsorsList.php');
            exit();
        } else {
            echo "Error creating sponsor: " . implode(", ", $stmt->errorInfo());
        }
    } catch (PDOException $e) {
        die('Connection failed: ' . $e->getMessage());
    }
}
?>
