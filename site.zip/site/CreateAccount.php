<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Account</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    /* Custom CSS */
    .form-container {
      max-width: 400px;
      margin: 0 auto; /* Center horizontally */
    }
  </style>
</head>
<body>

<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nume = trim($_POST['nume']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $type = trim($_POST['type']);

    if ($nume == "" || $username == "" || $password == "" || $type == "") {
        // Handle empty fields here
    } else {
        $sql = "INSERT INTO users (nume, username, password, type) VALUES ('$nume', '$username', '$password', '$type')";
        if (mysqli_query($db, $sql)) {
            header("Location: LoginAsUser.php");
        } else {
            die('Error: ' . mysqli_error($db));
        }
    }
}
?>

<!-- Meniul Top-bar: https://get.foundation/sites/docs/top-bar.php -->
<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

<div class="container mt-5">
  <h1 class="text-center">Create Account</h1>
  <div class="form-container">
    <form method="post" action="CreateAccount.php">
      <div class="form-group text-center">
        <label for="nume">Name:</label>
        <input type="text" class="form-control" id="nume" name="nume">
      </div>
      <div class="form-group text-center">
        <label for="username">Username:</label>
        <input type="text" class="form-control" id="username" name="username">
      </div>
      <div class="form-group text-center">
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password">
      </div>
      <div class="form-group text-center">
        <label for="type">Type:</label>
        <input type="text" class="form-control" id="type" name="type">
      </div>
      <button type="submit" class="btn btn-primary btn-block">Create Account</button>
    </form>
  </div>
</div>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
