<?php
$db = mysqli_connect("127.0.0.1", "root", "", "site");
if (!$db) {
    die('Connection failed: ' . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $creator = mysqli_real_escape_string($db, $_POST['creator']);
    $description = mysqli_real_escape_string($db, $_POST['description']);

    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
        $filename = $_FILES['thumbnail']['name'];
        $allowed = ['jpeg', 'jpg'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        if (!in_array($ext, $allowed)) {
            die("Error: Please select a valid file format (JPEG/JPG).");
        }
        
        if (!is_dir('uploads/')) {
            mkdir('uploads/', 0777, true);
        }
        
        $filepath = "uploads/" . $filename;
        move_uploaded_file($_FILES['thumbnail']['tmp_name'], $filepath);
        
        $sql = "INSERT INTO videos (thumbnail, name, creator, description, upload_date) VALUES ('$filepath', '$name', '$creator', '$description', NOW())";
        
        if (mysqli_query($db, $sql)) {
            ob_start();
            header('Location: UserAddVideo.php');
            ob_end_flush();
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($db);
        }
    } else {
        echo "Error: There was a problem uploading your file. Please try again.";
    }
}

mysqli_close($db);
?>
