<?php
$db = mysqli_connect("127.0.0.1", "root", "");
mysqli_select_db($db, "site");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $companie = mysqli_real_escape_string($db, $_POST['companie']);
    $joc = mysqli_real_escape_string($db, $_POST['joc']);
    $link = mysqli_real_escape_string($db, $_POST['link']);
    $status = isset($_POST['status']) ? 1 : 0;

    $query = "UPDATE livestreams SET companie='$companie', joc='$joc', link='$link', status=$status WHERE id=$id";
    if (mysqli_query($db, $query)) {
        header('Location: UserAddRemoveLive.php');
    } else {
        echo "Error updating record: " . mysqli_error($db);
    }
} else {
    echo "Invalid request!";
}
?>
