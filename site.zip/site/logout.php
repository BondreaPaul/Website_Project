<?php
session_start();
session_unset();
session_destroy();
header("Location: LoginAsUser.php");
exit();
?>
