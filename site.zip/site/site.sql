-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2024 at 10:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `site`
--

-- --------------------------------------------------------

--
-- Table structure for table `dashtext`
--

CREATE TABLE `dashtext` (
  `id` int(11) NOT NULL,
  `usertypeid` varchar(255) DEFAULT NULL,
  `contexttext` varchar(255) NOT NULL,
  `titlu` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dashtext`
--

INSERT INTO `dashtext` (`id`, `usertypeid`, `contexttext`, `titlu`) VALUES
(1, 'user', 'Welcome, username! <a href=\"UserProfile.php\">Profile<a href=\"logout.php\">Logout</a>', 'User Dashboard'),
(2, 'admin', 'Welcome, username! <a href=\"AdminProfile.php\">Profile <a href=\"logout.php\">Logout</a>', 'Admin Dashboard');

-- --------------------------------------------------------

--
-- Table structure for table `drepturi`
--

CREATE TABLE `drepturi` (
  `id` int(11) NOT NULL,
  `idpage` varchar(255) NOT NULL,
  `iduser` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drepturi`
--

INSERT INTO `drepturi` (`id`, `idpage`, `iduser`) VALUES
(1, '1', '2'),
(2, '2', '2'),
(3, '3', '2'),
(4, '4', '2'),
(5, '5', '2'),
(6, '6', '2'),
(7, '7', '2'),
(8, '8', '2'),
(9, '9', '2'),
(10, '10', '2'),
(11, '11', '1'),
(12, '12', '1'),
(13, '13', '1'),
(14, '14', '1'),
(15, '15', '1'),
(16, '16', '1'),
(17, '17', '1'),
(18, '18', '1'),
(19, '16', '3'),
(20, '17', '3'),
(21, '18', '3'),
(22, '19', '3'),
(25, '20', '3'),
(26, '21', '1'),
(27, '21', '2');

-- --------------------------------------------------------

--
-- Table structure for table `livestreams`
--

CREATE TABLE `livestreams` (
  `id` int(11) NOT NULL,
  `companie` varchar(255) NOT NULL,
  `joc` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `livestreams`
--

INSERT INTO `livestreams` (`id`, `companie`, `joc`, `link`, `status`) VALUES
(1, 'Companie1', 'Joc1', 'http://example.com/link1', 1),
(2, 'Companie2', 'Joc2', 'http://example.com/link2', 0),
(3, 'Companie3', 'Joc3', 'http://example.com/link3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pagini`
--

CREATE TABLE `pagini` (
  `id` int(11) NOT NULL,
  `numemenu` varchar(255) NOT NULL,
  `pagina` varchar(255) NOT NULL,
  `menu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pagini`
--

INSERT INTO `pagini` (`id`, `numemenu`, `pagina`, `menu`) VALUES
(1, 'AdminAddRemoveList', 'AdminAddRemoveList.php', 0),
(2, 'AdminAddVideo', 'AdminAddVideo.php', 0),
(3, 'AdminContextMenu', 'AdminContextMenu.php', 0),
(4, 'AdminCreateEntry', 'AdminCreateEntryfront.php', 0),
(5, 'AdminCreateEntry', 'AdminCreateEntry.php', 0),
(6, 'AdminDeleteEntry', 'AdminDeleteEntry.php', 0),
(7, 'AdminEntryEdit', 'AdminEntryEdit.php', 0),
(8, 'Main', 'AdminMainPage.php', 1),
(9, 'User List', 'AdminPlayerList.php', 1),
(10, 'Profile', 'AdminProfile.php', 1),
(11, 'UserAddRemoveLive', 'UserAddRemoveLive.php', 0),
(12, 'UserAddVideo', 'UserAddVideo.php', 0),
(13, 'UserCreateEntry', 'UserCreateEntry.php', 0),
(14, 'Main', 'UserMainPage.php', 1),
(15, 'Profile', 'UserProfile.php', 1),
(16, 'About', 'About.php', 1),
(17, 'TopBroadcasts', 'TopBroadcasts.php', 1),
(18, 'Search', 'Search.php', 1),
(19, 'Home', 'GamesBroadcasts.php', 1),
(20, 'Login', 'LoginAsUser.php', 1),
(21, 'Logout', 'logout.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nume` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nume`, `username`, `password`, `type`) VALUES
(1, 'user1', 'user', 'user', 'user'),
(2, 'admin1', 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `usertypes`
--

CREATE TABLE `usertypes` (
  `id` int(11) NOT NULL,
  `nume` varchar(255) NOT NULL,
  `redirect` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usertypes`
--

INSERT INTO `usertypes` (`id`, `nume`, `redirect`) VALUES
(1, 'user', 'UserMainPage.php'),
(2, 'admin', 'AdminMainPage.php'),
(3, 'guest', 'GamesBroadcasts.php');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `creator` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `upload_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dashtext`
--
ALTER TABLE `dashtext`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drepturi`
--
ALTER TABLE `drepturi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `livestreams`
--
ALTER TABLE `livestreams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pagini`
--
ALTER TABLE `pagini`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertypes`
--
ALTER TABLE `usertypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dashtext`
--
ALTER TABLE `dashtext`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `drepturi`
--
ALTER TABLE `drepturi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `livestreams`
--
ALTER TABLE `livestreams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pagini`
--
ALTER TABLE `pagini`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `usertypes`
--
ALTER TABLE `usertypes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
