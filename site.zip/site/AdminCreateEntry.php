<?php
$db = mysqli_connect("127.0.0.1", "root", "", "site");
if (!$db) {
    die('Connection failed: ' . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $companie = mysqli_real_escape_string($db, $_POST['companie']);
    $joc = mysqli_real_escape_string($db, $_POST['joc']);
    $link = mysqli_real_escape_string($db, $_POST['link']);
    $status = isset($_POST['status']) ? 1 : 0;

    $sql = "INSERT INTO livestreams (companie, joc, link, status) VALUES ('$companie', '$joc', '$link', '$status')";
    if (mysqli_query($db, $sql)) {
        header("Location: AdminAddRemoveLive.php");
    } else {
        echo "Error: " . mysqli_error($db);
    }
}
?>
