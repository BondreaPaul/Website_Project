<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> User's Profile</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh;
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .video-container {
    width: 40%; 
    margin: 0 auto; 
    padding: 20px;
    border: 1px solid #ccc;
    margin-bottom: 20px;
    }
    .scrolling-list {
    width: 80%;
    overflow-x: auto;
    white-space: nowrap;
    padding: 20px;
    border: 1px solid #ccc;
    margin: 0 auto;
    }
    .big-button-container {
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }
  </style>
</head>
<body>

<!-- Meniul Top-bar: https://get.foundation/sites/docs/top-bar.php -->
<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

  <div class="container">
    <!-- Profile picture and text box -->
    <div class="row justify-content-center">
      <div class="col-md-4">
        <div class="text-center">
          <img src="img/Fan.png" class="profile-picture mt-3 mb-3" alt="Profile Picture">
        </div>
        <div class="form-group">
          <input type="text" class="form-control" id="usernameInput" placeholder="New Username">
        </div>
        <a href="UserMainPage.php" class="btn btn-primary">Change Username</a>
      </div>
    </div>

    <!-- Text box for changing email -->
    <div class="row justify-content-center mt-5">
      <div class="col-md-4">
        <div class="form-group">
          <input type="email" class="form-control" id="emailInput" placeholder="New Email">
        </div>
        <a href="UserMainPage.php" class="btn btn-primary">Change Email</a>
      </div>
    </div>
    
    <div class="row justify-content-center mt-5">
      <form>
        <a href="UserAddRemoveLive.php" class="btn btn-primary big-button">Add/Remove Live stream</a>
      </form>
    </div>
    
    <div class="row justify-content-center mt-2">
      <form>
        <a href="UserAddVideo.php" class="btn btn-primary big-button">Add Video</a>
      </form>
    </div>
  
  <!-- Bootstrap JavaScript -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
