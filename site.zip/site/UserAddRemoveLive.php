<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User's Broadcasts</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
    .pagination {
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }
    .pagination .btn {
      margin: 0 5px;
    }
  </style>
</head>
<body>

<!-- Meniul Top-bar: https://get.foundation/sites/docs/top-bar.php -->
<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

<form method="post" action="includes/UserStreamingCautare.php">
  <div class="d-flex justify-content-center">
    <div class="input-group" style="max-width: 400px;">
      <input type="text" id="text" name="text" class="form-control" placeholder="Text">
      <button type="submit" name="submit" class="btn btn-primary" data-mdb-ripple-init>Caută<i class="fas fa-search"></i></button>
    </div>
  </div>
</form>

<?php
$db = mysqli_connect("127.0.0.1", "root", "", "site");
if (!$db) {
    die('Connection failed: ' . mysqli_connect_error());
}

$start = 0;
$limit = 5; // Modificat limita pe pagină la 5 înregistrări

$id = 1;
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $start = ($id - 1) * $limit;
}

$sqlv = "SELECT * FROM livestreams LIMIT $start, $limit";
$resultv = mysqli_query($db, $sqlv);

if (!$resultv) {
    die('Invalid query: ' . mysqli_error($db));
} else {
    echo "<div class='container'>
            <div class='table-container'>
                <table class='table table-striped'>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Companie</th>
                            <th>Joc</th>
                            <th>Link</th>
                            <th>Verified</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>";

    while ($myrow = mysqli_fetch_array($resultv, MYSQLI_ASSOC)) {
        echo "<tr>
                <td>{$myrow['id']}</td>
                <td>{$myrow['companie']}</td>
                <td>{$myrow['joc']}</td>
                <td><a href='" . htmlspecialchars($myrow['link']) . "'>" . htmlspecialchars($myrow['link']) . "</a></td>
                <td><input type='checkbox' class='form-check-input' disabled " . ($myrow['status'] ? "checked" : "") . "></td>
                <td>
                    <a href='UserEntryEdit.php?id={$myrow['id']}' class='btn btn-primary'>Edit</a>
                    <a href='UserEntryDelete.php?id={$myrow['id']}' class='btn btn-danger'>Delete</a>
                </td>
            </tr>";
    }

    echo "</tbody></table></div></div>";

    $rows = mysqli_num_rows(mysqli_query($db, "SELECT * FROM livestreams"));
    $totalPages = ceil($rows / $limit);

    echo "<div class='pagination'>";
    if ($id > 1) {
        echo "<a href='?id=" . ($id - 1) . "' class='btn btn-primary'>PREVIOUS</a>";
    }

    for ($i = 1; $i <= $totalPages; $i++) {
        if ($i == $id) {
            echo "<span class='btn btn-primary text-center'>$i</span>";
        } else {
            echo "<a href='?id=$i' class='btn btn-primary text-center'>$i</a>";
        }
    }

    if ($id < $totalPages) {
        echo "<a href='?id=" . ($id + 1) . "' class='btn btn-primary'>NEXT</a>";
    }
    echo "</div>";
}
?>

<div class="text-center">
  <a href="UserCreateEntry.php" class="btn btn-primary">Create New Entry</a>
</div>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


