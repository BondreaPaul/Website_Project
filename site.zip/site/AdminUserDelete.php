<?php
include 'connection.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "DELETE FROM users WHERE id=$id";

    if (mysqli_query($db, $query)) {
        header('Location: AdminPlayerList.php');
    } else {
        echo "Error deleting record: " . mysqli_error($db);
    }
} else {
    echo "Invalid request!";
}
?>
