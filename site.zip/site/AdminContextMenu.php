<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Admin's Homepage</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh; /* Adjust as needed */
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .video-container {
    width: 40%; 
    margin: 0 auto; 
    padding: 20px;
    border: 1px solid #ccc;
    margin-bottom: 20px;
    }
    .scrolling-list {
    width: 80%;
    overflow-x: auto;
    white-space: nowrap;
    padding: 20px;
    border: 1px solid #ccc;
    margin: 0 auto;
    }
  </style>
</head>
<body>

<!-- Meniul Top-bar: https://get.foundation/sites/docs/top-bar.php -->
<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <button type="button" class="btn btn-primary btn-block">Edit</button>
        <button type="button" class="btn btn-danger btn-block">Delete</button>
      </div>
    </div>
  </div>