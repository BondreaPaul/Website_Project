<?php
$db = mysqli_connect("127.0.0.1", "root", "", "site");
if (!$db) {
    die('Connection failed: ' . mysqli_connect_error());
}

$id = intval($_GET['id']);
$sql = "SELECT * FROM livestreams WHERE id = $id";
$result = mysqli_query($db, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $companie = mysqli_real_escape_string($db, $_POST['companie']);
    $joc = mysqli_real_escape_string($db, $_POST['joc']);
    $link = mysqli_real_escape_string($db, $_POST['link']);
    $status = isset($_POST['status']) ? 1 : 0;

    $update_sql = "UPDATE livestreams SET companie = '$companie', joc = '$joc', link = '$link', status = '$status' WHERE id = $id";
    if (mysqli_query($db, $update_sql)) {
        header("Location: AdminAddRemoveLive.php");
    } else {
        echo "Error updating record: " . mysqli_error($db);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin's Broadcasts</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh;
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<!-- Meniul Top-bar: https://get.foundation/sites/docs/top-bar.php -->
<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>

<!-- sfarist meniu topbar -->

<!-- Update Entry -->
<div class="row justify-content-center mt-3">
    <div class="col-md-6">
      <form method="post" action="AdminEntryEdit.php?id=<?php echo $id; ?>">
        <div class="form-group">
          <label for="companie">Companie</label>
          <input type="text" class="form-control" id="companie" name="companie" value="<?php echo htmlspecialchars($row['companie']); ?>">
        </div>
        <div class="form-group">
          <label for="joc">Joc</label>
          <input type="text" class="form-control" id="joc" name="joc" value="<?php echo htmlspecialchars($row['joc']); ?>">
        </div>
        <div class="form-group">
          <label for="link">Link</label>
          <input type="text" class="form-control" id="link" name="link" value="<?php echo htmlspecialchars($row['link']); ?>">
        </div>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="status" name="status" <?php echo $row['status'] ? 'checked' : ''; ?>>
          <label class="form-check-label" for="status">Verified</label>
        </div>
        <button type="submit" class="btn btn-success">Update</button>
      </form>
    </div>
  </div>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
