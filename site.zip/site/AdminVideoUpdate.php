<?php
$db = mysqli_connect("127.0.0.1", "root", "", "site");
if (!$db) {
    die('Connection failed: ' . mysqli_connect_error());
}

$id = intval($_GET['id']);
$sql = "SELECT * FROM videos WHERE id = $id";
$result = mysqli_query($db, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $creator = mysqli_real_escape_string($db, $_POST['creator']);
    $description = mysqli_real_escape_string($db, $_POST['description']);

    $thumbnail = $row['thumbnail'];
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == UPLOAD_ERR_OK) {
        $thumbnailTmpPath = $_FILES['thumbnail']['tmp_name'];
        $thumbnailName = basename($_FILES['thumbnail']['name']);
        $thumbnailPath = 'uploads/' . $thumbnailName;

        if (move_uploaded_file($thumbnailTmpPath, $thumbnailPath)) {
            $thumbnail = $thumbnailPath;
        } else {
            echo "Error uploading file.";
            exit();
        }
    }

    $query = "UPDATE videos SET name='$name', creator='$creator', description='$description', thumbnail='$thumbnail' WHERE id=$id";

    if (mysqli_query($db, $query)) {
        header("Location: AdminAddVideo.php");
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($db);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin's Videos</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh;
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

<div class="row justify-content-center mt-3">
    <div class="col-md-6">
      <form method="post" action="AdminVideoUpdate.php?id=<?php echo $id; ?>" enctype="multipart/form-data">
        <div class="form-group">
          <label for="thumbnail">Thumbnail</label>
          <input type="file" accept="image/jpeg" class="form-control" id="thumbnail" name="thumbnail">
          <img src="<?php echo htmlspecialchars($row['thumbnail']); ?>" alt="Current Thumbnail" style="width:100px;">
        </div>
        <div class="form-group">
          <label for="name">Name</label>
          <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($row['name']); ?>">
        </div>
        <div class="form-group">
          <label for="creator">Creator</label>
          <input type="text" class="form-control" id="creator" name="creator" value="<?php echo htmlspecialchars($row['creator']); ?>">
        </div>
        <div class="form-group">
          <label for="description">Description</label>
          <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($row['description']); ?></textarea>
        </div>
        <button type="submit" class="btn btn-success">Update</button>
      </form>
    </div>
  </div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
