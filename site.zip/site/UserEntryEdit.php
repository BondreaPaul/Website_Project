<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Entry</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .form-container {
      width: 50%;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

<div class="container">
  <div class="form-container">
    <h2>Edit Entry</h2>
    <?php
    $db = mysqli_connect("127.0.0.1", "root", "");
    mysqli_select_db($db, "site");

    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $result = mysqli_query($db, "SELECT * FROM livestreams WHERE id=$id");
        $row = mysqli_fetch_assoc($result);

        if (!$row) {
            echo "<p>Entry not found!</p>";
        } else {
            ?>
            <form action="UserEntryUpdate.php" method="post">
              <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
              <div class="form-group">
                <label for="companie">Companie</label>
                <input type="text" class="form-control" id="companie" name="companie" value="<?php echo htmlspecialchars($row['companie']); ?>" required>
              </div>
              <div class="form-group">
                <label for="joc">Joc</label>
                <input type="text" class="form-control" id="joc" name="joc" value="<?php echo htmlspecialchars($row['joc']); ?>" required>
              </div>
              <div class="form-group">
                <label for="link">Link</label>
                <input type="text" class="form-control" id="link" name="link" value="<?php echo htmlspecialchars($row['link']); ?>" required>
              </div>
              <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="status" name="status" <?php echo $row['status'] ? 'checked' : ''; ?>>
                <label class="form-check-label" for="status">Verified</label>
              </div>
              <button type="submit" class="btn btn-primary">Save Changes</button>
            </form>
            <?php
        }
    } else {
        echo "<p>Invalid request!</p>";
    }
    ?>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
