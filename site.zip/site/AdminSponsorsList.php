<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin's Sponsors List</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
    .pagination {
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }
    .pagination .btn {
      margin: 0 5px;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

<form method="post" action="AdminSponsorSearch.php">
  <div class="d-flex justify-content-center">
    <div class="input-group" style="max-width: 400px;">
      <input type="text" id="text" name="text" class="form-control" placeholder="Search Sponsors">
      <button type="submit" name="submit" class="btn btn-primary" data-mdb-ripple-init>Search<i class="fas fa-search"></i></button>
    </div>
  </div>
</form>

<?php
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=site', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}

$start = 0;
$limit = 5;

$id = 1;
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $start = ($id - 1) * $limit;
}

$sqlv = "SELECT * FROM sponsors LIMIT $start, $limit";
$resultv = $pdo->query($sqlv);

if ($resultv === false) {
    die('Invalid query: ' . implode(", ", $pdo->errorInfo()));
} else {
    echo "<div class='container'>
            <div class='table-container'>
                <table class='table table-striped'>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Company Name</th>
                            <th>Amount</th>
                            <th>Date Received</th>
                            <th>Company Site</th>
                            <th>Advert Length</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>";

    foreach ($resultv as $index => $myrow) {
        echo "<tr>
                <td>" . htmlspecialchars($myrow['id']) . "</td>
                <td>" . htmlspecialchars($myrow['companyname']) . "</td>
                <td>" . htmlspecialchars($myrow['amount']) . "</td>
                <td>" . htmlspecialchars($myrow['datereceived']) . "</td>
                <td><a href='" . htmlspecialchars($myrow['companysite']) . "'>" . htmlspecialchars($myrow['companysite']) . "</a></td>
                <td>" . htmlspecialchars($myrow['advertlength']) . "</td>
                <td>
                    <a href='AdminSponsorEdit.php?id=" . htmlspecialchars($myrow['id']) . "' class='btn btn-primary'>Edit</a>
                    <a href='AdminSponsorDelete.php?id=" . htmlspecialchars($myrow['id']) . "' class='btn btn-danger'>Delete</a>
                </td>
            </tr>";
    }

    echo "</tbody></table></div></div>";

    $rows = $pdo->query("SELECT COUNT(*) FROM sponsors")->fetchColumn();
    $totalPages = ceil($rows / $limit);

    echo "<div class='pagination'>";
    if ($id > 1) {
        echo "<a href='?id=" . ($id - 1) . "' class='btn btn-primary'>PREVIOUS</a>";
    }

    for ($i = 1; $i <= $totalPages; $i++) {
        if ($i == $id) {
            echo "<span class='btn btn-primary text-center'>$i</span>";
        } else {
            echo "<a href='?id=$i' class='btn btn-primary text-center'>$i</a>";
        }
    }

    if ($id < $totalPages) {
        echo "<a href='?id=" . ($id + 1) . "' class='btn btn-primary'>NEXT</a>";
    }
    echo "</div>";
}
?>

<div class="text-center">
  <a href="AdminSponsorCreate.php" class="btn btn-primary">Create New Sponsor</a>
  <a href="AdminMainPage.php" class="btn btn-primary">Return</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

