<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $nume = mysqli_real_escape_string($db, $_POST['nume']);
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $type = mysqli_real_escape_string($db, $_POST['type']);

    $query = "UPDATE users SET nume='$nume', username='$username', password='$password', type='$type' WHERE id=$id";

    if (mysqli_query($db, $query)) {
        header('Location: AdminPlayerList.php');
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($db);
    }
}
?>
