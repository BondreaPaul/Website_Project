<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Log In</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    /* Custom CSS */
    .form-container {
      max-width: 400px;
      margin: 0 auto; /* Center horizontally */
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function

if (isset($_SESSION["user_id"]) && $_SESSION["user_id"] != "") {
    // Fetch redirect page based on user type
    $user_type = $_SESSION["type"];
    $redirect_query = "SELECT redirect FROM usertypes WHERE nume = ?";
    $stmt = $db->prepare($redirect_query);
    $stmt->bind_param('s', $user_type);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        header("Location: " . $row['redirect']);
        exit();
    }
    $stmt->close();
}

$mode = "";
if (isset($_POST['mode'])) {
    $mode = $_POST['mode'];
}

if ($mode == "loginare") {
    $firstname = trim($_POST['firstname']);
    $pass = trim($_POST['user_password']);

    if ($firstname == "" || $pass == "") {
        // Handle empty fields here
        echo "Please fill in all fields.";
    } else {
        $sql = "SELECT * FROM users WHERE nume = '$firstname' AND password = '$pass'";
        $results = mysqli_query($db, $sql);
        if (!$results) {
            die('Invalid query: ' . mysqli_error($db));
        } else {
            $sql2 = mysqli_query($db, "SELECT users.id, users.nume, users.username, users.type
                                       FROM users 
                                       WHERE users.nume = '$firstname' AND users.password = '$pass'");
            $myrow1 = mysqli_fetch_array($sql2, MYSQLI_ASSOC);
            $rows = mysqli_num_rows($sql2);

            if ($rows > 0) {
                $_SESSION["user_id"] = $myrow1["id"];
                $_SESSION["name"] = $myrow1["nume"];
                $_SESSION["username"] = $myrow1["username"];
                $_SESSION["type"] = $myrow1["type"];

                // Redirect based on user type
                $user_type = $myrow1["type"];
                $redirect_query = "SELECT redirect FROM usertypes WHERE nume = ?";
                $stmt = $db->prepare($redirect_query);
                $stmt->bind_param('s', $user_type);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($row = $result->fetch_assoc()) {
                    header("Location: " . $row['redirect']);
                    exit();
                }
                $stmt->close();
            } else {
                // Handle invalid login
                echo "Invalid login credentials.";
            }
        }
    }
}
?>

<!-- Include this PHP code in all your HTML pages -->
<?= getTopBar($db) ?>
<!-- End top bar -->

<div class="container mt-5">
  <h1 class="text-center">Login</h1>
  <div class="form-container">
    <form method="post" action="LoginAsUser.php">
      <input type="hidden" name="mode" value="loginare">
      <div class="form-group text-center">
        <label for="firstname">First Name:</label>
        <input type="text" class="form-control" id="firstname" name="firstname">
      </div>
      <div class="form-group text-center">
        <label for="user_password">Password:</label>
        <input type="password" class="form-control" id="user_password" name="user_password">
      </div>
      <button type="submit" class="btn btn-primary btn-block">Login</button>
    </form>
    <br>
    <a href="CreateAccount.php" class="btn btn-primary btn-block">Create Account</a>
  </div>
</div>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>




