<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
$db = mysqli_connect("127.0.0.1", "root", "", "site"); 

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();
require_once 'functions.php';
?>
