<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Sponsor</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh;
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function

echo getTopBar($db);

// Database connection
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=site', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $companyname = $_POST['companyname'];
    $amount = $_POST['amount'];
    $datereceived = $_POST['datereceived'];
    $companysite = $_POST['companysite'];
    $advertlength = $_POST['advertlength'];

    $query = "UPDATE sponsors SET companyname=:companyname, amount=:amount, datereceived=:datereceived, companysite=:companysite, advertlength=:advertlength WHERE id=:id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':companyname', $companyname);
    $stmt->bindParam(':amount', $amount);
    $stmt->bindParam(':datereceived', $datereceived);
    $stmt->bindParam(':companysite', $companysite);
    $stmt->bindParam(':advertlength', $advertlength);
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        header('Location: AdminSponsorsList.php');
        exit();
    } else {
        echo "Error updating sponsor: " . implode(", ", $stmt->errorInfo());
    }
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = $pdo->prepare('SELECT * FROM sponsors WHERE id = :id');
    $query->bindParam(':id', $id, PDO::PARAM_INT);
    $query->execute();
    $sponsor = $query->fetch(PDO::FETCH_ASSOC);

    if (!$sponsor) {
        die('Sponsor not found');
    }
} else {
    die('Invalid request');
}
?>

<div class="container mt-5">
    <h1 class="text-center">Edit Sponsor</h1>
    <div class="form-container">
        <form method="post" action="AdminSponsorEdit.php">
            <input type="hidden" name="id" value="<?= htmlspecialchars($sponsor['id']) ?>">
            <div class="form-group">
                <label for="companyname">Company Name</label>
                <input type="text" class="form-control" id="companyname" name="companyname" value="<?= htmlspecialchars($sponsor['companyname']) ?>" required>
            </div>
            <div class="form-group">
                <label for="amount">Amount</label>
                <input type="number" class="form-control" id="amount" name="amount" value="<?= htmlspecialchars($sponsor['amount']) ?>" required>
            </div>
            <div class="form-group">
                <label for="datereceived">Date Received</label>
                <input type="date" class="form-control" id="datereceived" name="datereceived" value="<?= htmlspecialchars($sponsor['datereceived']) ?>" required>
            </div>
            <div class="form-group">
                <label for="companysite">Company Site</label>
                <input type="text" class="form-control" id="companysite" name="companysite" value="<?= htmlspecialchars($sponsor['companysite']) ?>" required>
            </div>
            <div class="form-group">
                <label for="advertlength">Advert Length</label>
                <input type="number" class="form-control" id="advertlength" name="advertlength" value="<?= htmlspecialchars($sponsor['advertlength']) ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

