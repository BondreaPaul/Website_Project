<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User's Homepage</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh; /* Adjust as needed */
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .video-container {
      width: 40%; 
      margin: 0 auto; 
      padding: 20px;
      border: 1px solid #ccc;
      margin-bottom: 20px;
    }
    .scrolling-list {
      width: 80%;
      overflow-x: auto;
      white-space: nowrap;
      padding: 20px;
      border: 1px solid #ccc;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function

?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- End top bar -->

<!-- Video Container -->
<div class="section video-container">
    <h2>Featured Stream</h2>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/C5Gm8UvxKlU" frameborder="0" allowfullscreen></iframe>
</div>

<!-- Scrolling List -->
<div class="section scrolling-list">
    <h2>Recommended Streams</h2>
    <div class="video-item">
        <iframe width="200" height="150" src="https://www.youtube.com/embed/MTJ-_gvNmbA" frameborder="0" allowfullscreen></iframe>
        <h3>Stream 1</h3>
    </div>
</div>

<div class="container-table">
    <div class="section">
      <h1>Recommended for You</h1>
      <!-- Table Container -->
    <div class="container">
    <table class="table table-bordered table-striped">
    <thead class="thead-dark">
      <tr>
        <th>Company</th>
        <th>Game</th>
        <th>Site</th>
        <th>Site 2</th>
        <th>Live Status</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Row 1, Column 1</td>
        <td>Row 1, Column 2</td>
        <td>Row 1, Column 3</td>
        <td>Row 1, Column 4</td>
        <td>Row 1, Column 5</td>
      </tr>
      <tr>
        <td>Row 2, Column 1</td>
        <td>Row 2, Column 2</td>
        <td>Row 2, Column 3</td>
        <td>Row 2, Column 4</td>
        <td>Row 2, Column 5</td>
      </tr>
      <tr>
        <td>Row 3, Column 1</td>
        <td>Row 3, Column 2</td>
        <td>Row 3, Column 3</td>
        <td>Row 3, Column 4</td>
        <td>Row 3, Column 5</td>
      </tr>
    </tbody>
  </table>
</div>

<div class="section">
    <h1>Top Broadcasts</h1>
    <!-- Table Container -->
    <div class="container">
    <table class="table table-bordered table-striped">
    <thead class="thead-dark">
      <tr>
        <th>Company</th>
        <th>Game</th>
        <th>Site</th>
        <th>Site 2</th>
        <th>Live Status</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Row 1, Column 1</td>
        <td>Row 1, Column 2</td>
        <td>Row 1, Column 3</td>
        <td>Row 1, Column 4</td>
        <td>Row 1, Column 5</td>
      </tr>
      <tr>
        <td>Row 2, Column 1</td>
        <td>Row 2, Column 2</td>
        <td>Row 2, Column 3</td>
        <td>Row 2, Column 4</td>
        <td>Row 2, Column 5</td>
      </tr>
      <tr>
        <td>Row 3, Column 1</td>
        <td>Row 3, Column 2</td>
        <td>Row 3, Column 3</td>
        <td>Row 3, Column 4</td>
        <td>Row 3, Column 5</td>
      </tr>
    </tbody>
  </table>
</div>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>




