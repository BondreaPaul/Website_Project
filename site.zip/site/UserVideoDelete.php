<?php
$db = mysqli_connect("127.0.0.1", "root", "", "site");

if (!$db) {
    die('Connection failed: ' . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "DELETE FROM videos WHERE id=$id";

    if (mysqli_query($db, $query)) {
        header('Location: UserAddVideo.php');
    } else {
        echo "Error deleting record: " . mysqli_error($db);
    }
} else {
    echo "Invalid request!";
}
?>
