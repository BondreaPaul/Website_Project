<!DOCTYPE HTML>  
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adaugarea in BD</title>
    <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/motion-ui@1.2.3/dist/motion-ui.min.css" />
    <link rel="stylesheet" href="css/app.css">
</head>
<body> 
    <br><br><br>

    <?php
    $db = mysqli_connect("127.0.0.1", "root", "", "site");

    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $companie = $_POST["companie"];
        $joc = $_POST["joc"];
        $link = $_POST["link"];
        $status = isset($_POST['status']) ? 1 : 0;
        
        $sql = "INSERT INTO livestreams (companie, joc, link, Status) VALUES ('$companie', '$joc', '$link','$status')";
        
        echo $sql;
        echo "</br>";

        
        $results= mysqli_query($db,$sql);
        if (!$results)
                die('Invalid querry:' .mysqli_error($db));
        else 
            {
                header("Location: ../UserAddRemoveLive.php");
            }
    }

    mysqli_close($db);
    ?>

    <a href="UserEntryCreated.php" class="button">Vizualizare</a><br>
    <a href="operatii.php" class="button">Operatii</a>

    <script src="js/vendor/jquery.js"></script>
    <script src="js/vendor/what-input.js"></script>
    <script src="js/vendor/foundation.js"></script>
    <script src="js/app.js"></script>
</body>
</html>
