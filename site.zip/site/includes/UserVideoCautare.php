<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> User's Cautare</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<!-- Meniul Top-bar: https://get.foundation/sites/docs/top-bar.html -->
<?php
session_start();
include 'connection.php';

$user_type = isset($_SESSION['type']) ? $_SESSION['type'] : 'guest';
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Login';

function getTopBar($db, $user_type, $username) {
    $profile_link = 'LoginAsUser.php';
    $main_page = 'GamesBroadcasts.php';
    
    if ($user_type == 'Admin') {
        $profile_link = 'AdminProfile.php';
        $main_page = 'AdminMainPage.php';
    } elseif ($user_type == 'User') {
        $profile_link = 'UserProfile.php';
        $main_page = 'UserMainPage.php';
    }

    if ($user_type != 'guest') {
        $sql = "SELECT contexttext FROM dashtext WHERE usertypeid = '$user_type'";
        $result = mysqli_query($db, $sql);
        if ($result) {
            $row = mysqli_fetch_assoc($result);
            $welcome_text = str_replace('username', $username, $row['contexttext']);
        } else {
            $welcome_text = '<span>Welcome, <a href="' . $profile_link . '">' . $username . '</a>! <a href="logout.php">Logout</a></span>';
        }
    } else {
        $welcome_text = '<li><a href="LoginAsUser.php">Login</a></li>';
    }
    
    return '
    <div class="top-bar">
      <div class="top-bar-left">
        <ul class="menu">
          <li class="menu-text">GamesBroadcasts</li>
          <li><a href="' . $main_page . '">Home</a></li>
          <li><a href="About.php">About</a></li>
          <li><a href="Search.php">Search</a></li>
          <li><a href="TopBroadcasts.php">Top Broadcasts</a></li>
        </ul>
      </div>
      <div class="top-bar-right">
        ' . $welcome_text . '
      </div>
    </div>';
}
?>

<!-- Include this PHP code in all your HTML pages -->
<?= getTopBar($db, $user_type, $username) ?>
<!-- sfarist meniu topbar -->

<form method="post" action="UserVideoCautare.php">
  <div class="d-flex justify-content-center">
    <div class="input-group" style="max-width: 400px;">
      <input type="text" id="text" name="text" class="form-control" placeholder="Text">
      <button type="submit" name="submit" class="btn btn-primary" data-mdb-ripple-init>Caută<i class="fas fa-search"></i></button>
    </div>
  </div>
</form>

<?php
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=site', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}

$SW = 0;

if (isset($_POST['submit'])) {
    $key = $_POST['text'];
    $query = $pdo->prepare('SELECT * FROM videos WHERE name LIKE :keyword OR creator LIKE :keyword OR description LIKE :keyword');
    $query->bindValue(':keyword', '%'.$key.'%', PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_ASSOC);
    $rows = $query->rowCount();

    $SW = 1;
}

if ($SW == 1) {
    if ($rows > 0) {
        echo "<div class='container'>
        <div class='table-container'>
          <table class='table table-striped'>
            <thead>
              <tr>
                <th>#</th>
                <th>Thumbnail</th>
                <th>Name</th>
                <th>Creator</th>
                <th>Description</th>
                <th>Upload Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>";
        foreach ($results as $index => $myrow) {
            echo "<tr>";
            echo "<th scope='row'>" . htmlspecialchars($index + 1) . "</th>";
            echo "<td><img src='/" . htmlspecialchars($myrow['thumbnail']) . "' alt='Thumbnail' style='width: 50px; height: 50px;'></td>";
            echo "<td>" . htmlspecialchars($myrow['name']) . "</td>";
            echo "<td>" . htmlspecialchars($myrow['creator']) . "</td>";
            echo "<td>" . htmlspecialchars($myrow['description']) . "</td>";
            echo "<td>" . htmlspecialchars($myrow['upload_date']) . "</td>";
            echo "<td>
                    <a href='.../UserVideoUpdate.php?id=" . htmlspecialchars($myrow['id']) . "' class='btn btn-primary'>Edit</a>
                    <a href='.../UserVideoDelete.php?id=" . htmlspecialchars($myrow['id']) . "' class='btn btn-danger'>Delete</a>
                  </td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
        echo "</div></div>";
    } else {
        echo "<br>Nu s-a găsit nicio înregistrare care să corespundă căutării!";
    }
}
?>
<div class="text-center">
  <a href="UserVideoCreateEntry.php" class="btn btn-primary">Create New Entry</a>
  <a href="UserAddVideo.php" class="btn btn-primary">Return</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

