<?php
// Start the session and include the connection file
session_start();
include 'connection.php';

// Database connection
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=site', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}

// Check if the 'id' parameter is present in the query string
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Prepare the SQL DELETE statement
    $query = $pdo->prepare('DELETE FROM sponsors WHERE id = :id');
    $query->bindParam(':id', $id, PDO::PARAM_INT);

    // Execute the query and check for errors
    if ($query->execute()) {
        // Redirect to the sponsors list page after successful deletion
        header('Location: AdminSponsorsList.php');
        exit();
    } else {
        echo "Error deleting sponsor: " . implode(", ", $query->errorInfo());
    }
} else {
    // Handle the case where the 'id' parameter is not provided
    die('Invalid request');
}
?>

