<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Admin's Homepage</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .dropdown-menu {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
    }
    .dropdown-menu li {
      padding: 12px 16px;
    }
    .dropdown-menu li a {
      color: black;
      text-decoration: none;
      display: block;
    }
    .dropdown-menu li:hover {
      background-color: #f1f1f1;
    }
    .menu > li:hover .dropdown-menu {
      display: block;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh;
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .video-container {
      width: 40%; 
      margin: 0 auto; 
      padding: 20px;
      border: 1px solid #ccc;
      margin-bottom: 20px;
    }
    .scrolling-list {
      width: 80%;
      overflow-x: auto;
      white-space: nowrap;
      padding: 20px;
      border: 1px solid #ccc;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<!-- Meniul Top-bar: https://get.foundation/sites/docs/top-bar.html -->
<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- End top bar -->

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>