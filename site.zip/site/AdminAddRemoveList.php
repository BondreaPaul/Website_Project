<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin's Broadcasts</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh;
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .table-container {
      width: 80%;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<!-- Meniul Top-bar: https://get.foundation/sites/docs/top-bar.html -->
<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>

<!-- sfarist meniu topbar -->

</br>
<div class="d-flex justify-content-center">
  <div class="input-group" style="max-width: 400px;">
    <input type="search" id="form1" class="form-control" />
    <div class="input-group-append">
      <button type="button" class="btn btn-primary" data-mdb-ripple-init>
        Search
        <i class="fas fa-search"></i>
      </button>
    </div>
  </div>
</div>
</br>

<?php
$db = mysqli_connect("127.0.0.1", "root", "", "site");
if (!$db) {
    die('Connection failed: ' . mysqli_connect_error());
}

$sql = "SELECT * FROM livestreams";
$result = mysqli_query($db, $sql);

if (!$result) {
    die('Invalid query: ' . mysqli_error($db));
} else {
    echo "<div class='container'>
            <div class='table-container'>
                <table class='table table-striped'>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Companie</th>
                            <th>Joc</th>
                            <th>Link</th>
                            <th>Verified</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>";

    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['companie']}</td>
                <td>{$row['joc']}</td>
                <td><a href='" . htmlspecialchars($row['link']) . "'>" . htmlspecialchars($row['link']) . "</a></td>
                <td><input type='checkbox' class='form-check-input' disabled " . ($row['status'] ? "checked" : "") . "></td>
                <td>
                    <a href='AdminEntryEdit.php?id={$row['id']}' class='btn btn-primary'>Edit</a>
                    <a href='AdminDeleteEntry.php?id={$row['id']}' class='btn btn-danger'>Delete</a>
                </td>
            </tr>";
    }

    echo "</tbody></table></div></div>";
}
?>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
