<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin's Homepage</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .dropdown-menu {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
    }
    .dropdown-menu li {
      padding: 12px 16px;
    }
    .dropdown-menu li a {
      color: black;
      text-decoration: none;
      display: block;
    }
    .dropdown-menu li:hover {
      background-color: #f1f1f1;
    }
    .menu > li:hover .dropdown-menu {
      display: block;
    }
    .container-table {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      height: 100vh;
    }
    .section {
      margin-bottom: 20px;
      text-align: center;
    }
    .video-container {
      width: 40%; 
      margin: 0 auto; 
      padding: 20px;
      border: 1px solid #ccc;
      margin-bottom: 20px;
    }
    .scrolling-list {
      width: 80%;
      overflow-x: auto;
      white-space: nowrap;
      padding: 20px;
      border: 1px solid #ccc;
      margin: 0 auto;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- End top bar -->

<!-- Video Container -->
<div class="section video-container">
    <h2>Featured Stream</h2>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/C5Gm8UvxKlU" frameborder="0" allowfullscreen></iframe>
</div>

<!-- Scrolling List -->
<div class="section scrolling-list">
    <h2>Recommended Streams</h2>
    <div class="video-item">
        <iframe width="200" height="150" src="https://www.youtube.com/embed/MTJ-_gvNmbA" frameborder="0" allowfullscreen></iframe>
        <h3>Stream 1</h3>
    </div>
</div>

<div class="container-table">
    <div class="section">
      <h1>Recent Broadcasts</h1>
      <!-- Table Container -->
    <div class="container">
    <table class="table table-bordered table-striped">
    <thead class="thead-dark">
      <tr>
        <th>Company</th>
        <th>Game</th>
        <th>Site</th>
        <th>Site 2</th>
        <th>Live Status</th>
        <th>Context Menu</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Row 1, Column 1</td>
        <td>Row 1, Column 2</td>
        <td>Row 1, Column 3</td>
        <td>Row 1, Column 4</td>
        <td>Row 1, Column 5</td>
        <td><a href="AdminContextMenu.php">Row 1, Column 6</a></td>
      </tr>
      <tr>
        <td>Row 2, Column 1</td>
        <td>Row 2, Column 2</td>
        <td>Row 2, Column 3</td>
        <td>Row 2, Column 4</td>
        <td>Row 2, Column 5</td>
        <td><a href="AdminContextMenu.php">Row 2, Column 6</a></td>
      </tr>
      <tr>
        <td>Row 3, Column 1</td>
        <td>Row 3, Column 2</td>
        <td>Row 3, Column 3</td>
        <td>Row 3, Column 4</td>
        <td>Row 3, Column 5</td>
        <td><a href="AdminContextMenu.php">Row 3, Column 6</a></td>
      </tr>
    </tbody>
  </table>
</div>

<br>
<div class="section">
    <h1>Top Broadcasts</h1>
    <!-- Table Container -->
    <div class="container">
    <table class="table table-bordered table-striped">
    <thead class="thead-dark">
      <tr>
        <th>Company</th>
        <th>Game</th>
        <th>Site</th>
        <th>Site 2</th>
        <th>Live Status</th>
        <th>Context Menu</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Row 1, Column 1</td>
        <td>Row 1, Column 2</td>
        <td>Row 1, Column 3</td>
        <td>Row 1, Column 4</td>
        <td>Row 1, Column 5</td>
        <td><a href="AdminContextMenu.php">Row 1, Column 6</a></td>
      </tr>
      <tr>
        <td>Row 2, Column 1</td>
        <td>Row 2, Column 2</td>
        <td>Row 2, Column 3</td>
        <td>Row 2, Column 4</td>
        <td>Row 2, Column 5</td>
        <td><a href="AdminContextMenu.php">Row 2, Column 6</a></td>
      </tr>
      <tr>
        <td>Row 3, Column 1</td>
        <td>Row 3, Column 2</td>
        <td>Row 3, Column 3</td>
        <td>Row 3, Column 4</td>
        <td>Row 3, Column 5</td>
        <td><a href="AdminContextMenu.php">Row 3, Column 6</a></td>
      </tr>
    </tbody>
  </table>
</div>

<!-- Bootstrap JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>


