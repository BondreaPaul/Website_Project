<?php
$db = mysqli_connect("127.0.0.1", "root", "");
mysqli_select_db($db, "site");

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "DELETE FROM livestreams WHERE id=$id";

    if (mysqli_query($db, $query)) {
        header('Location: UserAddRemoveLive.php');
    } else {
        echo "Error deleting record: " . mysqli_error($db);
    }
} else {
    echo "Invalid request!";
}
?>
