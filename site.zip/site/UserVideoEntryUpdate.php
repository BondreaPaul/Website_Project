<?php
$db = mysqli_connect("127.0.0.1", "root", "", "site");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $creator = mysqli_real_escape_string($db, $_POST['creator']);
    $description = mysqli_real_escape_string($db, $_POST['description']);

    $thumbnail = "";
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == UPLOAD_ERR_OK) {
        $thumbnailTmpPath = $_FILES['thumbnail']['tmp_name'];
        $thumbnailName = basename($_FILES['thumbnail']['name']);
        $thumbnailPath = 'uploads/' . $thumbnailName;
        
        if (move_uploaded_file($thumbnailTmpPath, $thumbnailPath)) {
            $thumbnail = $thumbnailPath;
        } else {
            echo "Error uploading file.";
            exit();
        }
    } else {
        $thumbnail = mysqli_real_escape_string($db, $_POST['thumbnail']);
    }

    $query = "UPDATE videos SET name='$name', creator='$creator', description='$description', thumbnail='$thumbnail' WHERE id=$id";
    
    if (mysqli_query($db, $query)) {
        header("Location: UserAddVideo.php");
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($db);
    }
}
?>

