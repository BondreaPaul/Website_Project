<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit User</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function

// Generate the top bar
echo getTopBar($db);

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = mysqli_query($db, "SELECT * FROM users WHERE id=$id");
    $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
} else {
    echo "Invalid request!";
    exit();
}
?>

<div class="container mt-5">
  <h1 class="text-center">Edit User</h1>
  <div class="form-container">
    <form method="post" action="AdminUserUpdate.php">
      <input type="hidden" name="id" value="<?= $user['id'] ?>">
      <div class="form-group">
        <label for="nume">First Name:</label>
        <input type="text" class="form-control" id="nume" name="nume" value="<?= $user['nume'] ?>">
      </div>
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" class="form-control" id="username" name="username" value="<?= $user['username'] ?>">
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="text" class="form-control" id="password" name="password" value="<?= $user['password'] ?>">
      </div>
      <div class="form-group">
        <label for="type">User Type:</label>
        <input type="text" class="form-control" id="type" name="type" value="<?= $user['type'] ?>">
      </div>
      <button type="submit" class="btn btn-primary">Update</button>
    </form>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
