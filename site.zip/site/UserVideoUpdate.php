<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Video</title>
  <link rel="stylesheet" href="https://dhbhdrzi4tiry.cloudfront.net/cdn/sites/foundation.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .top-bar {
      margin-bottom: 20px;
    }
    .form-container {
      width: 50%;
      margin: 0 auto;
    }
    .thumbnail-preview {
      width: 100px;
      height: auto;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>

<?php
session_start();
include 'connection.php';
include 'topbar.php'; // Include the topbar function
?>

<!-- Include the top bar -->
<?= getTopBar($db) ?>
<!-- sfarist meniu topbar -->

<div class="container">
  <div class="form-container">
    <h2>Edit Video</h2>
    <?php
    $db = mysqli_connect("127.0.0.1", "root", "", "site");

    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $result = mysqli_query($db, "SELECT * FROM videos WHERE id=$id");
        $row = mysqli_fetch_assoc($result);

        if (!$row) {
            echo "<p>Video not found!</p>";
        } else {
            ?>
            <form action="UserVideoEntryUpdate.php" method="post" enctype="multipart/form-data">
              <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
              <div class="form-group">
                <label for="thumbnail">Thumbnail</label>
                <?php
                $thumbnailPath = htmlspecialchars($row['thumbnail']);
                if (file_exists($thumbnailPath)) {
                  echo "<img src='$thumbnailPath' alt='Thumbnail' class='thumbnail-preview'>";
                } else {
                  echo "<p>Thumbnail not found: $thumbnailPath</p>";
                }
                ?>
                <input type="file" class="form-control-file" id="thumbnail" name="thumbnail">
              </div>
              <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
              </div>
              <div class="form-group">
                <label for="creator">Creator</label>
                <input type="text" class="form-control" id="creator" name="creator" value="<?php echo htmlspecialchars($row['creator']); ?>" required>
              </div>
              <div class="form-group">
                <label for="description">Description</label>
                <input type="text" class="form-control" id="description" name="description" value="<?php echo htmlspecialchars($row['description']); ?>" required>
              </div>
              <button type="submit" class="btn btn-primary">Save Changes</button>
            </form>
            <?php
        }
    } else {
        echo "<p>Invalid request!</p>";
    }
    ?>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


